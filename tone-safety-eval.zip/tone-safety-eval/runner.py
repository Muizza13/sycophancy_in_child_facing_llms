"""Run every (case x model x condition) through the 3-turn pressure protocol
and write one transcript record per combination to a JSONL file.

Usage:
  python runner.py --mock                       # offline smoke test
  python runner.py --out runs/transcripts.jsonl # real run (needs API keys)
  python runner.py --limit 3                    # only first 3 cases
"""
import argparse
import json
import os

from models import build_models
from scenarios import SYSTEM_PROMPTS, child_turns, load_cases


def run_one(model, system, case):
    """Walk the 3-turn conversation, feeding the model its own prior replies."""
    messages = []
    turns_out = []
    for i, child_msg in enumerate(child_turns(case), start=1):
        messages.append({"role": "user", "content": child_msg})
        meta = {
            "turn": i,
            "correct_answer": case["correct_answer"],
            "wrong_answer": case["child_wrong_answer"],
            "case_id": case["id"],
        }
        reply = model.chat(messages, system, meta=meta)
        messages.append({"role": "assistant", "content": reply})
        turns_out.append({"turn": i, "child": child_msg, "model": reply})
    return turns_out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", default="test_cases.json")
    ap.add_argument("--out", default="runs/transcripts.jsonl")
    ap.add_argument("--mock", action="store_true")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--conditions", default="naive,pedagogical")
    args = ap.parse_args()

    cases = load_cases(args.cases)
    if args.limit:
        cases = cases[: args.limit]
    models = build_models(mock=args.mock)
    conditions = args.conditions.split(",")

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    n = 0
    with open(args.out, "w") as f:
        for case in cases:
            for model in models:
                for cond in conditions:
                    turns = run_one(model, SYSTEM_PROMPTS[cond], case)
                    rec = {
                        "case_id": case["id"],
                        "error_type": case["error_type"],
                        "subject": case["subject"],
                        "correct_answer": case["correct_answer"],
                        "child_wrong_answer": case["child_wrong_answer"],
                        "answer_pattern": case.get("answer_pattern", ""),
                        "model": model.name,
                        "condition": cond,
                        "turns": turns,
                    }
                    f.write(json.dumps(rec) + "\n")
                    n += 1
                    print(f"  {case['id']:10s} {model.name:20s} {cond}")
    print(f"\nWrote {n} transcripts to {args.out}")


if __name__ == "__main__":
    main()
