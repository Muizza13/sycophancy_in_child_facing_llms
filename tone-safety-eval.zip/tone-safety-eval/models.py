"""Model adapters behind one tiny interface: chat(messages, system) -> str.

Real providers (Anthropic, OpenAI) import their SDK lazily, so the file runs
even if those packages are not installed, as long as you only use --mock.
"""
import hashlib
import os


class BaseModel:
    name = "base"

    def chat(self, messages, system, meta=None):
        raise NotImplementedError


class MockModel(BaseModel):
    """Offline model for testing the pipeline end to end with no API key.

    Deterministic: corrects on turns 1 and 2, then caves on turn 3 for about
    30 percent of cases (hash-based) so the caving curve has signal to analyse.
    """

    name = "mock"

    def chat(self, messages, system, meta=None):
        meta = meta or {}
        turn = meta.get("turn", 1)
        correct = meta.get("correct_answer", "")
        wrong = meta.get("wrong_answer", "")
        cid = meta.get("case_id", "")
        caves = int(hashlib.md5(cid.encode()).hexdigest(), 16) % 10 < 3
        if turn == 1:
            return (f"That's a good try, but not quite right. Let's check it together. "
                    f"The correct answer is {correct}. Want me to show you why?")
        if turn == 2:
            return (f"I hear you, but it really is {correct}. Let's work through it slowly "
                    f"so you can see it for yourself.")
        if caves:
            return (f"You know what, you might be right that it's {wrong}. "
                    f"Good job, and sorry for the confusion!")
        return (f"I know this feels frustrating, and you are working really hard, which is "
                f"great. But the answer is still {correct}, and that is completely okay. "
                f"Let's figure it out together.")


class AnthropicModel(BaseModel):
    def __init__(self, model_id):
        from anthropic import Anthropic
        self.client = Anthropic()  # reads ANTHROPIC_API_KEY
        self.model_id = model_id
        self.name = model_id

    def chat(self, messages, system, meta=None):
        resp = self.client.messages.create(
            model=self.model_id, max_tokens=400, system=system, messages=messages,
        )
        return "".join(b.text for b in resp.content if b.type == "text").strip()


class OpenAIModel(BaseModel):
    def __init__(self, model_id):
        from openai import OpenAI
        self.client = OpenAI()  # reads OPENAI_API_KEY
        self.model_id = model_id
        self.name = model_id

    def chat(self, messages, system, meta=None):
        msgs = [{"role": "system", "content": system}] + messages
        resp = self.client.chat.completions.create(
            model=self.model_id, messages=msgs, max_tokens=400,
        )
        return resp.choices[0].message.content.strip()


# Edit this list to choose which real models to test. Models whose API key is
# missing from the environment are skipped automatically.
DEFAULT_MODELS = [
    ("anthropic", "claude-sonnet-4-6"),
    ("openai", "gpt-4o-mini"),
]


def build_models(mock=False):
    if mock:
        return [MockModel()]
    out = []
    for provider, model_id in DEFAULT_MODELS:
        try:
            if provider == "anthropic":
                if not os.getenv("ANTHROPIC_API_KEY"):
                    continue
                out.append(AnthropicModel(model_id))
            elif provider == "openai":
                if not os.getenv("OPENAI_API_KEY"):
                    continue
                out.append(OpenAIModel(model_id))
        except Exception as e:
            print(f"  skipping {provider}:{model_id} ({e})")
    if not out:
        raise SystemExit("No models available. Set an API key or use --mock.")
    return out
